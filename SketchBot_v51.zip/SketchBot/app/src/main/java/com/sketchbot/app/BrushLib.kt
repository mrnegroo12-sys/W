package com.sketchbot.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import org.json.JSONArray
import org.json.JSONObject

/**
 * فرشاة في المكتبة. samples = قياسات حقيقية [Size، عرض الخط بالبكسل على الشاشة]
 * بين القياسات نستكمل خطياً، فنعرف عرض أي Size من 1 إلى 100 بدقة أعلى من نقطتين فقط.
 * role: 0 عام، 1 تعبئة، 2 خطوط
 */
class Brush(
    val id: Long,
    var name: String,
    val samples: MutableList<FloatArray>,
    var role: Int,
    var on: Boolean
) {
    fun px(size: Float): Float {
        val s = samples
        if (s.isEmpty()) return 1f
        if (s.size == 1) return Math.max(0.5f, s[0][1] * size / Math.max(1f, s[0][0]))
        var i = 0
        while (i < s.size - 2 && size > s[i + 1][0]) i++
        val a = s[i]
        val b = s[i + 1]
        val dx = b[0] - a[0]
        val slope = if (dx == 0f) 0f else (b[1] - a[1]) / dx
        return Math.max(0.5f, a[1] + slope * (size - a[0]))
    }

    /** أقرب Size (1..100) يعطي عرضاً قريباً من المطلوب */
    fun sizeFor(target: Float): Int {
        var best = 1
        var bd = Float.MAX_VALUE
        for (s in 1..100) {
            val d = Math.abs(px(s.toFloat()) - target)
            if (d < bd) { bd = d; best = s }
        }
        return best
    }

    fun minPx(): Float = px(1f)
    fun maxPx(): Float = px(100f)
}

/** خيار تعبئة جاهز: فرشاة + Size + مسافة الخطوط الناتجة (بكسل الصورة) + عرضها الفعلي (بكسل الصورة) */
class TierOpt(val brush: Long, val size: Int, val gap: Int, val widthImg: Float)

/** يختار الفرشاة والحجم الأنسب لعرض مطلوب */
interface Chooser {
    val minGap: Int
    val maxGap: Int
    fun fill(gapImg: Int): TierOpt?
    fun line(widthImg: Float): TierOpt?
}

class LibChooser(
    all: List<Brush>,
    primaryId: Long,
    private val scale: Float,
    taught: Set<Long>,
    private val cover: Float = 0.6f
) : Chooser {
    // نستعمل الفرشاة الأساسية (يختارها المستخدم يدوياً قبل البدء) + الفرشات المُعلَّمة فقط (يمكن للبوت اختيارها وحده)
    private val usable: List<Brush> = all.filter { it.on && (it.id == primaryId || it.id in taught) }
    private val fills: List<Brush> = usable.filter { it.role != 2 }.ifEmpty { usable }
    private val lines: List<Brush> = usable.filter { it.role == 2 }.ifEmpty { usable }

    // scale = بكسل الشاشة لكل بكسل صورة؛ gap = cover × عرض الفرشاة (الافتراضي 0.6 أي تداخل 40%)
    private fun gapOf(widthScreen: Float): Int = Math.max(1, Math.round(widthScreen / scale * cover))

    override val minGap: Int
        get() {
            var m = Int.MAX_VALUE
            for (b in fills) m = Math.min(m, gapOf(Math.max(2f, b.px(1f))))
            return if (m == Int.MAX_VALUE) 1 else m
        }

    override val maxGap: Int
        get() {
            var m = 1
            for (b in fills) m = Math.max(m, gapOf(b.px(100f)))
            return m
        }

    private fun pick(list: List<Brush>, widthScreen: Float): TierOpt? {
        var best: TierOpt? = null
        var bs = Float.MAX_VALUE
        for (b in list) {
            val s = b.sizeFor(widthScreen)
            val actual = b.px(s.toFloat())
            val err = Math.abs(actual - widthScreen) / Math.max(1f, widthScreen)
            // تفضيل الأحجام المتوسطة (قياسها أدق) إن تساوت الفرشاتان في المطابقة
            val score = err + 0.002f * Math.abs(s - 50)
            if (score < bs) {
                bs = score
                best = TierOpt(b.id, s, gapOf(actual), actual / scale)
            }
        }
        return best
    }

    override fun fill(gapImg: Int): TierOpt? = pick(fills, gapImg / cover * scale)
    override fun line(widthImg: Float): TierOpt? = pick(lines, widthImg * scale)
}

object BrushLib {
    private const val KEY = "brushLib"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("sb", Context.MODE_PRIVATE)

    fun load(ctx: Context): MutableList<Brush> {
        val out = ArrayList<Brush>()
        try {
            val arr = JSONArray(prefs(ctx).getString(KEY, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val sa = o.getJSONArray("s")
                val samples = ArrayList<FloatArray>()
                for (j in 0 until sa.length()) {
                    val p = sa.getJSONArray(j)
                    samples.add(floatArrayOf(p.getDouble(0).toFloat(), p.getDouble(1).toFloat()))
                }
                samples.sortBy { it[0] }
                out.add(Brush(o.getLong("id"), o.getString("name"), samples, o.optInt("role", 0), o.optBoolean("on", true)))
            }
        } catch (_: Throwable) {}
        return out
    }

    fun save(ctx: Context, list: List<Brush>) {
        val arr = JSONArray()
        for (b in list) {
            val o = JSONObject()
            o.put("id", b.id)
            o.put("name", b.name)
            o.put("role", b.role)
            o.put("on", b.on)
            val sa = JSONArray()
            for (s in b.samples) sa.put(JSONArray().put(s[0].toDouble()).put(s[1].toDouble()))
            o.put("s", sa)
            arr.put(o)
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun add(ctx: Context, name: String, samples: List<FloatArray>, role: Int): Brush {
        val list = load(ctx)
        var id = System.currentTimeMillis()
        while (list.any { it.id == id }) id++
        val sorted = ArrayList(samples)
        sorted.sortBy { it[0] }
        val b = Brush(id, name, sorted, role, true)
        list.add(b)
        save(ctx, list)
        return b
    }

    fun remove(ctx: Context, id: Long) {
        val list = load(ctx)
        list.removeAll { it.id == id }
        save(ctx, list)
        prefs(ctx).edit().remove("bsel_$id").apply()
    }

    /** الفرشات التي عُلِّم لها موضع الاختيار في Sketchbook (يستطيع البوت التبديل إليها تلقائياً) */
    fun taught(ctx: Context): Set<Long> {
        val out = HashSet<Long>()
        for (k in prefs(ctx).all.keys) {
            if (k.startsWith("bsel_")) k.removePrefix("bsel_").toLongOrNull()?.let { out.add(it) }
        }
        return out
    }

    /** أول تشغيل: نحوّل معايرة الفرشاة القديمة (الصغيرة والكبيرة) إلى فرشاة في المكتبة */
    fun seed(ctx: Context) {
        val p = prefs(ctx)
        if (p.contains(KEY)) return
        val small = p.getFloat("brushScreen", 0f)
        val big = p.getFloat("bigScreen", 0f)
        val list = ArrayList<Brush>()
        if (small > 0f) {
            val s = ArrayList<FloatArray>()
            s.add(floatArrayOf(10f, small))
            if (big > small) s.add(floatArrayOf(20f, big))
            list.add(Brush(1L, "الفرشاة الحالية", s, 0, true))
        }
        save(ctx, list)
    }
}

/** محاكاة: ترسم الخطة نفسها بعرض كل فرشاة الحقيقي، فترى كيف ستخرج الصورة في Sketchbook */
object Sim {
    fun render(phases: List<Phase>, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        for (ph in phases) {
            if (ph.tiers.isEmpty()) continue
            p.color = 0xFF000000.toInt() or ph.color
            for (t in ph.tiers) {
                p.strokeWidth = Math.max(1f, t.widthImg)
                val path = Path()
                for (st in t.strokes) {
                    if (st.size < 2) continue
                    path.moveTo(st[0].x, st[0].y)
                    for (k in 1 until st.size) path.lineTo(st[k].x, st[k].y)
                }
                cv.drawPath(path, p)
            }
        }
        return bmp
    }
}
